package repositories;
import entities.Articulo;
import entities.ArticuloEnvasado;
import entities.ArticuloLimpieza;
import entities.ArticuloSuelto;
import java.util.ArrayList;
import java.util.List;
public class ArticuloRepository {
    private List<Articulo>lista;
    public ArticuloRepository() {
        lista=new ArrayList();
        lista.add(new ArticuloEnvasado(1.5, "Coca-Cola Zero", 20));
        lista.add(new ArticuloEnvasado(1.5, "Coca-Cola", 18));
        lista.add(new ArticuloLimpieza("500ml", "Shampoo Sedal", 19));
        lista.add(new ArticuloSuelto("kilo", "Frutillas", 64));
    }
    public List<Articulo>getAll(){ return lista; }
}
