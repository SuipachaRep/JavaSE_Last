package clase22ejercicioentrevista;
import entities.Articulo;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import repositories.ArticuloRepository;
public class Clase22EjercicioEntrevista {
    public static void main(String[] args) {
        // Ejercicio Entrevista Laboral
        List<Articulo>lista=new ArticuloRepository().getAll();
        lista.forEach(item->System.out.println(item+"\n"));
        System.out.println("=============================");
        Set<Articulo>set=new TreeSet();
        set.addAll(lista);
        lista.addAll(set);
        System.out.println("Producto más caro: "+lista.get(lista.size()-1).getNombre());
        System.out.println("Producto más barato: "+lista.get(0).getNombre());
    }    
}