package entities;
public abstract class Articulo implements Comparable<Articulo>{
    protected String nombre;
    protected int precio;
    public Articulo(String nombre, int precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
    @Override public int compareTo(Articulo articulo) {
        int valor=0;
        if(this.precio<articulo.precio) valor=-1;
        else valor=1;
        return valor;
    }
    public String getNombre() { return nombre; }
    
}