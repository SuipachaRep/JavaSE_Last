package entities;
public class ArticuloSuelto extends Articulo{
    private String unidadDeVenta;
    public ArticuloSuelto(String unidadDeVenta, String nombre, int precio) {
        super(nombre, precio);
        this.unidadDeVenta = unidadDeVenta;
    }
    @Override public String toString(){
        return "Nombre: "+nombre+" /// Precio: $"+precio
                +" /// Unidad de venta: "+unidadDeVenta;
    }
}