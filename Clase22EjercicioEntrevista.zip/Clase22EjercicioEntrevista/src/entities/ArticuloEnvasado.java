package entities;
public class ArticuloEnvasado extends Articulo{
    private double litros;
    public ArticuloEnvasado(double litros, String nombre, int precio) {
        super(nombre, precio);
        this.litros = litros;
    }
    @Override public String toString(){
        return "Nombre: "+nombre+" /// Litros: "+litros+" /// Precio: $"+precio;
    }
}