package entities;
public class ArticuloLimpieza extends Articulo {
    private String contenido;
    public ArticuloLimpieza(String contenido, String nombre, int precio) {
        super(nombre, precio);
        this.contenido = contenido;
    }
    @Override public String toString(){
        return "Nombre: "+nombre+" /// Contenido: "+contenido+" /// Precio: $"+precio;
    }
}